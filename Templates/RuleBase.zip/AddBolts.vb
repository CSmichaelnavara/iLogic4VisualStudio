﻿Imports Inventor
Public Class $safeitemname$
    Inherits RuleBase

    Public Overrides Sub Main()
        Throw New NotImplementedException()
    End Sub
End Class
